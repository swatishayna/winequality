1. create virtual environment
2. activate the environment
3. create requirements.txt
4. install the requirements
   
   ``` manually create```
5. Create data and data_given folder
6. make  template.py file
   
``` manualy fetch and put inside data _given folder```

7. Put fetched data inside data_given folder
